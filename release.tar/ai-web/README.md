# ai-web
ai server kumpulan script penting yang sering
digunakan seperti alat hacking, editor text dan banyak lagi

# Update aiv1.4
penambahan rincian isi path pada tools filemanager
dan save scrolling cache pada editor text tradisional

# Update aiv1.9
penambahan galery untuk membuka kumpulan gambar musik dan video
fitur ini bisa dibuka dengan klik filemanager other lalu pilih
galery image atau yang lain.

#Update aiv1.10
Penambahan gallery document untuk membuka file pdf, fitur ini
bisa dibuka di filemanager sama seperti gallery yang lain

#Update aiv2.4
versi stabil, file tar untuk mendapatkan release<br>

![](output.gif)

# Requitments
1). php 7 keatas <br>
2). ffmpeg <br>
3). pdftoppm <br>

# Install 
1). copy folder ai-web ke server <br>
2). tes menggunakan localhost/ai-web/ai.php <br>
3). finish <br>

